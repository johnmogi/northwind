import React, { Component } from 'react';
import { ProductModel } from '../../models/product-model';


interface ProductState{
    products:ProductModel[];
}

// class Products extends React.Component{
export class Products extends Component<any, ProductState> { 

    public constructor(props:any){
        super(props);
        this.state = {
            products:[]
        }
    }
    public componentDidMount(): void{
        fetch("http://localhost:4000/api/products")
        .then(res => res.json())
        .then(products => this.setState({products}))
        .catch(err=>alert(err.message));
    }
   public render(): JSX.Element{ 
        return ( 
            <div className="products container ">
            <h2>{this.state.products.length}</h2>
            <div className=" row">
{this.state.products.map(p => 
<div className="card text-white bg-info col-4" >
  <div className="card-body">{p.name}
    <h5 className="card-title">{p.price}</h5>
    <p className="card-text">{p.stock}</p>
    </div>
    </div>
)};
</div>
</div>
        );
}
}
export default Products