import React, { Component } from "react";
import "./layout.css";
import { Header } from "../header/header";
import { Main } from "../main/main";

import Footer from "../footer/footer";
import { BrowserRouter, Redirect, Switch, Route } from "react-router-dom";
import Home from "../home/home";
import About from "../about/about";
import Products from "../products/products";


export class Layout extends Component {
    public render(): JSX.Element {
        return (
            <div className="layout container-fluid bg-dark">
<BrowserRouter> 
<header ><Header /></header>

<Switch>
<Route path="/home" component={Home} exact />
<Route path="/products" component={Products} exact />
<Route path="/about" component={About} exact />
<Redirect from="/" to="/home" exact />
{/* <Route component={PageNotFound} /> */}
</Switch>
</BrowserRouter>

<footer> <Footer /></footer>
            </div>
        );
    }

  

}

