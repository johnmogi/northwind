import React from 'react';
 
class Footer extends React.Component{

    render() { 
        return ( 
<div className="footer text-center">
    <h6>
    All rights reserved &copy;
</h6>
</div>

         );
    }
}
 
export default Footer;