import React from "react";
import "./header.css";
import { NavLink} from "react-router-dom"

 export const Header = () => {
    return (
        <div className="header ">
            <section className="container"> 
          <nav className="navbar navbar-expand-lg navbar-light bg-light ">
  <a className="navbar-brand" href="#">Northwind</a>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>


  <div className="collapse navbar-collapse  navbar-nav" id="navbarNav">



<NavLink to="/home" exact className="nav-link"> Home </NavLink>
<NavLink to="/about" exact className="nav-link"> About </NavLink>
<NavLink to="/products" exact className="nav-link"> Products </NavLink>


        {/* <a className="nav-link" href="#">Home <span className="sr-only">(current)</span></a> */}

  </div>
</nav>
</section>
</div>
    );
};

